import React from 'react'

const Footer = () => {
  return (
    <footer>
        <div className='d-flex justify-content-center'>

        
        @copyright 2022-2023. All Rights Reserved.</div></footer>
  )
}

export default Footer