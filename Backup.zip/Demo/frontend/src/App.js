import './App.css';
import Account from './components/account/Account';

function App() {
  return (
<Account/>
  );
}

export default App;
