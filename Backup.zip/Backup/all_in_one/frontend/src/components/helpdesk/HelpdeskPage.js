import React from 'react'

const HelpdeskPage = () => {
  return (
    <div>
      HelpdeskHome
    </div>
  )
}

export default HelpdeskPage
