import React from 'react'
import axios from 'axios'

const Axios = () => {
  const [post, setPost] = React.useState(null);
  const [error, setError] = React.useState(null);

  return (
    <div>Axios</div>
  )
}

export default Axios