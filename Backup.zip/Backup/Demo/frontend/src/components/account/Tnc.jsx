import React from 'react'

const Tnc = () => {
  return (
    <>
    <h1>Terms and Conditions</h1>
    <hr/>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores, doloremque aspernatur. Sint, et minus, esse nemo aspernatur nihil, veniam dolorem illum eum odit fugiat facere natus itaque repudiandae quae? Consequatur exercitationem perferendis soluta, nobis labore ab enim possimus accusantium itaque. Deserunt nostrum sunt totam obcaecati ea culpa officiis quaerat quasi fugiat? Dolorem accusantium atque eveniet quasi necessitatibus quaerat vitae est, alias minus a debitis sequi corrupti ut iusto ratione, et quia voluptas. Officiis voluptatibus ratione nobis id odit voluptatum, magni atque, aperiam facere unde quibusdam illum provident omnis, vitae recusandae error magnam a. Nam quisquam adipisci odio delectus ipsum totam?</p>
    </>

  )
}

export default Tnc